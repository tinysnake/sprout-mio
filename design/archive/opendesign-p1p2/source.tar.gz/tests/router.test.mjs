import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {JSDOM, VirtualConsole} from 'jsdom';
import {createHashRouter, hashLinkFrom, installPageLinks, isPrimaryClick, resolvePageHref, assignPage} from '../src/router.mjs';

const wait = (ms = 20) => new Promise(resolve => setTimeout(resolve, ms));
const silent = {error() {}};

function fixture(hash = '', html = '<a id="link" href="#/agents/wenxu">闻序</a>') {
  return new JSDOM(`<!doctype html><body>${html}</body>`, {url: `http://localhost/app.html${hash}`, pretendToBeVisual: true});
}

function press(win, el, init = {}) {
  const event = new win.MouseEvent('click', {bubbles: true, cancelable: true, button: 0, ...init});
  el.dispatchEvent(event);
  return event;
}

test('点击同文档 hash 链接：拦截默认导航、直接写状态、URL 同步', () => {
  const dom = fixture();
  const win = dom.window;
  const seen = [];
  const router = createHashRouter({win, logger: silent});
  router.setApplier(href => seen.push(href));
  router.mount();
  try {
    const event = press(win, win.document.getElementById('link'));
    assert.equal(event.defaultPrevented, true, '默认导航必须被拦截');
    assert.deepEqual(seen, ['#/agents/wenxu'], '状态由 applier 直接写入，不等 hashchange');
    assert.equal(win.location.hash, '#/agents/wenxu');
  } finally {
    router.unmount();
    win.close();
  }
});

test('不接管修饰键、非 hash、新窗口、下载与空锚点', () => {
  const dom = fixture('', `
    <a id="hash" href="#/agents/a">a</a>
    <a id="blank" href="#/agents/b" target="_blank">b</a>
    <a id="download" href="#/agents/c" download>c</a>
    <a id="empty" href="#">d</a>
    <a id="page" href="sprout-mio.html">e</a>
    <a id="external" href="https://example.com">f</a>`);
  const win = dom.window;
  const seen = [];
  const router = createHashRouter({win, logger: silent});
  router.setApplier(href => seen.push(href));
  router.mount();
  try {
    const d = win.document;
    assert.equal(press(win, d.getElementById('blank')).defaultPrevented, false);
    assert.equal(press(win, d.getElementById('download')).defaultPrevented, false);
    assert.equal(press(win, d.getElementById('empty')).defaultPrevented, false);
    assert.equal(press(win, d.getElementById('page')).defaultPrevented, false);
    assert.equal(press(win, d.getElementById('external')).defaultPrevented, false);
    assert.equal(press(win, d.getElementById('hash'), {metaKey: true}).defaultPrevented, false);
    assert.equal(press(win, d.getElementById('hash'), {button: 1}).defaultPrevented, false);
    assert.deepEqual(seen, [], '这些点击都不该进入应用路由');
    assert.equal(hashLinkFrom(d.getElementById('blank')), null);
    assert.equal(hashLinkFrom(d.getElementById('page')), null);
    assert.equal(isPrimaryClick({button: 2}), false);
    assert.equal(isPrimaryClick({button: 0, ctrlKey: true}), false);
    assert.equal(isPrimaryClick({button: 0}), true);
  } finally {
    router.unmount();
    win.close();
  }
});

test('宿主提前 preventDefault 并吞掉 hashchange 时，链接仍由脚本接管', async () => {
  const dom = fixture('');
  const win = dom.window;
  // 预览宿主常见做法：对全部链接 preventDefault，并阻断 hashchange 传播。
  win.addEventListener('click', event => {
    if (event.target?.closest?.('a[href^="#"]')) event.preventDefault();
  }, true);
  win.addEventListener('hashchange', event => event.stopImmediatePropagation(), true);
  const seen = [];
  const router = createHashRouter({win, logger: silent});
  router.setApplier(href => seen.push(href));
  router.mount();
  try {
    const event = press(win, win.document.getElementById('link'));
    assert.equal(event.defaultPrevented, true);
    assert.deepEqual(seen, ['#/agents/wenxu'], '不依赖 hashchange 也必须完成页面切换');
  } finally {
    router.unmount();
    win.close();
  }
});

test('应用器抛错不阻断路由，URL 仍可定位，之后还能恢复', () => {
  const dom = fixture();
  const win = dom.window;
  const failures = [];
  const router = createHashRouter({win, logger: {error: e => failures.push(e.message)}});
  router.setApplier(() => { throw new Error('渲染失败'); });
  try {
    const result = router.navigate('#/agents/wenxu');
    assert.equal(result.applied, false);
    assert.equal(result.synced, true, '状态失败时 URL 同步仍要尽力完成，便于刷新定位');
    assert.deepEqual(failures, ['渲染失败']);
    const seen = [];
    router.setApplier(href => seen.push(href));
    assert.deepEqual(router.navigate('#/projects'), {applied: true, synced: true});
    assert.deepEqual(seen, ['#/projects']);
  } finally {
    win.close();
  }
});

test('hashchange 只处理外部触发的 URL 变化（前进/后退）', async () => {
  const dom = fixture();
  const win = dom.window;
  const seen = [];
  const router = createHashRouter({win, logger: silent});
  router.setApplier(href => seen.push(href));
  router.mount();
  try {
    win.location.hash = '#/agents/zhiheng';
    await wait();
    assert.deepEqual(seen, ['#/agents/zhiheng']);
  } finally {
    router.unmount();
    win.close();
  }
});

test('卸载后不再接管点击；没有应用器时退回 hashchange 广播', () => {
  const dom = fixture();
  const win = dom.window;
  let seen = 0;
  const router = createHashRouter({win, logger: silent});
  const off = router.setApplier(() => { seen += 1; });
  const unmount = router.mount();
  try {
    press(win, win.document.getElementById('link'));
    assert.equal(seen, 1);
    unmount();
    assert.equal(router.mounted, false);
    press(win, win.document.getElementById('link'));
    assert.equal(seen, 1, '卸载后必须完全停止接管');
  } finally {
    off();
    win.close();
  }

  const dom2 = fixture();
  const win2 = dom2.window;
  const broadcasts = [];
  win2.addEventListener('hashchange', () => broadcasts.push(win2.location.hash));
  const router2 = createHashRouter({win: win2, logger: silent});
  router2.mount();
  try {
    press(win2, win2.document.getElementById('link'));
    assert.deepEqual(broadcasts, ['#/agents/wenxu'], '应用器缺失时由事件广播兜底');
  } finally {
    router2.unmount();
    win2.close();
  }
});

test('resolvePageHref 只在拿到可导航地址时放行', () => {
  const served = resolvePageHref('sprout-mio.html', {href: 'http://localhost/app/index.html'});
  assert.equal(served.navigable, true);
  assert.equal(served.href, 'http://localhost/app/sprout-mio.html');
  assert.equal(served.file, 'sprout-mio.html');

  // srcdoc / blob 承载的文档没有可导航的基地址：相对链接必须判为不可导航。
  assert.deepEqual(resolvePageHref('sprout-mio.html', {href: 'about:srcdoc'}).navigable, false);
  assert.equal(resolvePageHref('sprout-mio.html', {href: 'about:srcdoc'}).reason, 'no-base');
  assert.equal(resolvePageHref('javascript:alert(1)', {href: 'http://localhost/'}).navigable, false);
  assert.equal(resolvePageHref('data:text/html,x', {href: 'http://localhost/'}).navigable, false);
  assert.equal(resolvePageHref('', {href: 'http://localhost/'}).navigable, false);
});

function fakeWindow({href = 'http://localhost/app/index.html'} = {}) {
  const listeners = new Map();
  const link = {href: 'sprout-mio.html', getAttribute(name) { return name === 'href' ? this.href : null; }, setAttribute(name, value) { if (name === 'href') this.href = value; }};
  const win = {
    location: {href, assigned: null, assign(url) { this.assigned = url; }},
    link,
    addEventListener(type, fn) { if (!listeners.has(type)) listeners.set(type, []); listeners.get(type).push(fn); },
    removeEventListener(type, fn) { listeners.set(type, (listeners.get(type) || []).filter(item => item !== fn)); },
    click(init = {}) {
      const event = {button: 0, target: {closest: () => link}, defaultPrevented: false, preventDefault() { this.defaultPrevented = true; }, ...init};
      for (const fn of listeners.get('click') || []) fn(event);
      return event;
    },
  };
  return win;
}

test('installPageLinks：可导航时落成绝对地址并放行默认导航', () => {
  const win = fakeWindow();
  const blocked = [];
  const off = installPageLinks({win, onBlocked: detail => blocked.push(detail)});
  try {
    const event = win.click();
    assert.equal(event.defaultPrevented, false, '可导航的链接必须交给浏览器，保留新标签页等默认行为');
    assert.equal(win.link.href, 'http://localhost/app/sprout-mio.html');
    assert.deepEqual(blocked, []);
  } finally {
    off();
  }
});

test('installPageLinks：宿主给不出可导航地址时拦截并回报，不留死链', () => {
  const win = fakeWindow({href: 'about:srcdoc'});
  const blocked = [];
  const off = installPageLinks({win, onBlocked: detail => blocked.push(detail)});
  try {
    const event = win.click();
    assert.equal(event.defaultPrevented, true);
    assert.deepEqual(blocked, [{href: 'sprout-mio.html', file: 'sprout-mio.html', reason: 'no-base'}]);
  } finally {
    off();
  }
});

test('assignPage：不可导航时返回失败，不假装已经跳转', () => {
  const served = fakeWindow();
  assert.equal(assignPage('sprout-mio.html', {win: served}).navigated, true);
  assert.equal(served.location.assigned, 'http://localhost/app/sprout-mio.html');

  const srcdoc = fakeWindow({href: 'about:srcdoc'});
  const result = assignPage('sprout-mio.html', {win: srcdoc});
  assert.equal(result.navigated, false);
  assert.equal(srcdoc.location.assigned, null);
});

test('hash 路由与链接接管只存在于 router 模块', async () => {
  const source = await readFile(new URL('../src/app.jsx', import.meta.url), 'utf8');
  assert.ok(!/location\.hash\s*=/.test(source), 'src/app.jsx 不应直接写 location.hash');
  assert.ok(!/syncHash/.test(source), 'URL 同步应收敛到 router.sync');
  assert.ok(!/addEventListener\('click'/.test(source), '链接接管应收敛到 router 模块');
  assert.match(source, /createHashRouter\(/);
  assert.match(source, /installPageLinks\(/);
});

// ── 其余页面的链接审计 ─────────────────────────────────────────────
// 登录页、组件样板、演示索引没有 hash 路由，但它们有跨文档链接：宿主若给不出可导航地址，
// 这些链接同样会「点了没反应」。审计规则：任何非 hash 链接都必须标了 data-page-link，
// 从而被 installPageLinks 守卫；同时这三页不得混入 hash 链接。
const pages = [
  ['sprout-login.html', 'auth-screen'],
  ['sprout-components.html', 'component-catalog'],
  ['index.html', 'demo-index'],
];

for (const [file, rootId] of pages) {
  test(`${file} 的链接不依赖 URL 事件，且跨文档链接都被守卫覆盖`, async () => {
    const html = await readFile(new URL('../' + file, import.meta.url), 'utf8');
    const vc = new VirtualConsole();
    const dom = new JSDOM(html, {url: `http://localhost/${file}`, runScripts: 'dangerously', pretendToBeVisual: true, virtualConsole: vc, beforeParse(w) {
      Object.defineProperty(w, 'innerWidth', {value: 1440});
    }});
    const d = dom.window.document;
    try {
      for (let i = 0; i < 40 && !d.querySelector(`[data-od-id="${rootId}"]`); i++) await wait();
      assert.ok(d.querySelector(`[data-od-id="${rootId}"]`), `${file} 未挂载`);

      const anchors = [...d.querySelectorAll('a[href]')];
      assert.deepEqual(
        anchors.filter(a => (a.getAttribute('href') || '').startsWith('#')).map(a => a.getAttribute('href')),
        [],
        `${file} 不应依赖 hash 路由`,
      );
      const cross = anchors.filter(a => !(a.getAttribute('href') || '').startsWith('#'));
      if (file !== 'sprout-login.html') assert.ok(cross.length > 0, `${file} 应有跨文档链接可审计`);
      const unguarded = cross.filter(a => !a.hasAttribute('data-page-link'));
      assert.deepEqual(unguarded.map(a => a.getAttribute('href')), [], `${file} 存在未被守卫的跨文档链接`);
    } finally {
      dom.window.close();
    }
  });
}

test('工作台：hash 链接由脚本接管，账号菜单等跨文档链接都被守卫覆盖', async () => {
  const html = await readFile(new URL('../sprout-mio.html', import.meta.url), 'utf8');
  const vc = new VirtualConsole();
  const dom = new JSDOM(html, {url: 'http://localhost/sprout-mio.html#/projects/sprout-refactor/agents', runScripts: 'dangerously', pretendToBeVisual: true, virtualConsole: vc, beforeParse(w) {
    Object.defineProperty(w, 'innerWidth', {value: 1440});
  }});
  const w = dom.window, d = w.document;
  try {
    for (let i = 0; i < 40 && !d.querySelector('[data-od-id="workspace-shell"]'); i++) await wait();
    const cross = [...d.querySelectorAll('a[href]')].filter(a => !(a.getAttribute('href') || '').startsWith('#'));
    assert.deepEqual(cross.filter(a => !a.hasAttribute('data-page-link')).map(a => a.getAttribute('href')), []);
    // 账号菜单是工作台唯一的跨文档出口，必须同样被守卫，否则宿主拦截时点击毫无反馈。
    const account = d.querySelector('[data-od-id="account-menu"]');
    assert.ok(account, '侧栏底部应有账号入口');
    account.click();
    await wait(30);
    const menuLinks = [...d.querySelectorAll('[data-od-id="account-popover"] a[href]')];
    assert.ok(menuLinks.length >= 3);
    for (const link of menuLinks) assert.ok(link.hasAttribute('data-page-link'), `账号菜单链接未被守卫：${link.getAttribute('href')}`);
  } finally {
    dom.window.close();
  }
});

test('390px 外壳的 iframe src 同样显式解析，不可导航时给出说明而不是空白', async () => {
  const html = await readFile(new URL('../sprout-mobile.html', import.meta.url), 'utf8');
  assert.ok(!/frame\.src\s*=\s*["']sprout-mio\.html/.test(html), 'iframe src 不应直接写相对地址');
  assert.match(html, /new URL\("sprout-mio\.html"/);
  assert.match(html, /mobile-app-unavailable/);
  assert.match(html, /frame\.remove\(\)/);
});

import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {JSDOM,VirtualConsole} from 'jsdom';
const html=await readFile(new URL('../sprout-mio.html',import.meta.url),'utf8');
const wait=()=>new Promise(r=>setTimeout(r,40));
async function mount(hash='chats/architecture/info',width=1440,theme='light'){
 const errors=[],vc=new VirtualConsole();vc.on('jsdomError',e=>errors.push(e.message));
 const dom=new JSDOM(html,{url:`http://localhost/sprout-mio.html?theme=${theme}#/projects/sprout-refactor/${hash}`,runScripts:'dangerously',pretendToBeVisual:true,virtualConsole:vc,beforeParse(w){Object.defineProperty(w,'innerWidth',{value:width})}});
 const w=dom.window,d=w.document;
 // 等到 React 真正挂载出界面再操作，否则早期事件会落在尚未绑定监听的节点上。
 for(let i=0;i<40&&!d.querySelector('[data-od-id="workspace-shell"]');i++)await wait();
 const get=id=>d.querySelector(`[data-od-id="${id}"]`);
 // React 会把同一状态同步回受控输入框，因此输入后要等到值真的落进组件状态再继续。
 const click=async id=>{const el=get(id);assert.ok(el,`缺少入口 ${id}`);el.click();await wait()};
 // 负载高时受控输入可能吞掉一次合成事件，这里重试到值真的落进 React 状态为止。
 const enter=async (id,value)=>{const el=get(id);assert.ok(el,`缺少输入框 ${id}`);const proto=el.tagName==='TEXTAREA'?w.HTMLTextAreaElement.prototype:w.HTMLInputElement.prototype;for(let attempt=0;attempt<8;attempt++){Object.getOwnPropertyDescriptor(proto,'value').set.call(el,value);el.dispatchEvent(new w.Event('input',{bubbles:true}));await wait();if(get(id)?.value===value)return}throw new Error(`输入未生效：${id}`)};
 return{dom,w,d,get,click,enter,errors};
}
test('项目页面在主区切换且菜单唯一选中，返回对话后保留草稿',async()=>{
 const {dom,w,d,get,click,enter,errors}=await mount();
 try{
  // 顶部 header 已取消：账号与收起按钮在侧栏底部，主题紧邻聊天头部的 Info Hub。
  assert.equal(get('workspace-header'),null);assert.ok(get('sidebar-foot').querySelector('[data-od-id="account-menu"]'));assert.ok(get('sidebar-foot').querySelector('[data-od-id="toggle-sidebar"]'));assert.equal(get('sidebar-foot').querySelector('[data-od-id="theme-toggle"]'),null);assert.equal(get('toggle-inspector').previousElementSibling,get('theme-toggle'));assert.ok(get('chat-pane').querySelector('[data-od-id="toggle-inspector"]'));
  await enter('message-input','请保留仓库证据。');
  const items=[...get('project-submenu').querySelectorAll('button')].map(el=>el.textContent.trim());
  assert.deepEqual(items,['Chats','Members','Project settings']);
  for(const [id,page]of [['project-members','members'],['project-settings','settings']]){
   await click(id);assert.ok(get(`project-${page}-page`));assert.equal(d.querySelector('[role="dialog"]'),null);assert.equal(get('chat-list'),null);assert.equal(get('info-hub'),null);assert.match(w.location.hash,new RegExp('/'+page+'$'));
   const selected=d.querySelectorAll('[data-od-id="sidebar-menu"] [aria-current="page"]');assert.equal(selected.length,1);assert.equal(selected[0],get(id));
  }
  // URL back-navigation restores the preceding page, not a modal.
  w.history.back();await wait();assert.ok(get('project-members-page'));
  assert.equal(get('project-members-list').querySelectorAll('article').length,5);
  await click('project-chats');await click('chat-architecture');
  assert.equal(get('message-input').value,'请保留仓库证据。');assert.ok(get('active-run'));assert.equal(errors.length,0,errors.join('\n'));
 }finally{dom.window.close()}
});
test('设置校验、重置与保存都作用于当前 Project',async()=>{
 const {dom,w,d,get,click,enter,errors}=await mount('settings');
 try{
  assert.equal(get('save-project-settings').disabled,true);
  await enter('project-name-input','');get('project-settings-form').dispatchEvent(new w.Event('submit',{bubbles:true,cancelable:true}));await wait();assert.match(d.querySelector('[role="alert"]').textContent,/不能为空/);
  assert.match(get('sidebar-project-selector-trigger').textContent,/Sprout Mio 重构/);
  // 侧栏顶部承担 Project 切换；顶栏只保留当前页面名，不再重复选择器与斜杠。
  assert.match(get('sidebar-brand').textContent,/Sprout Mio 重构/);
  assert.equal(get('workspace-header'),null);assert.equal(get('project-page-title').textContent,'Project settings');
  await click('reset-project-settings');assert.equal(get('project-name-input').value,'Sprout Mio 重构');assert.equal(d.querySelector('[role="alert"]'),null);
  await enter('project-name-input','Sprout Mio 协作');await click('save-project-settings');assert.match(get('sidebar-project-selector-trigger').textContent,/Sprout Mio 协作/);assert.match(d.querySelector('[role="status"]').textContent,/设置已保存/);assert.equal(get('save-project-settings').disabled,true);
  await click('project-members');await click('project-settings');assert.equal(get('project-name-input').value,'Sprout Mio 协作');assert.equal(errors.length,0,errors.join('\n'));
 }finally{dom.window.close()}
});
test('Members 和设置支持直接链接，窄屏 Project 入口使用同一主区路由',async()=>{
 for(const [page,width,theme]of [['members',1440,'light'],['settings',1440,'dark'],['members',390,'dark'],['settings',390,'light']]){
  const {dom,w,d,get,click,errors}=await mount(page,width,theme);
  try{
   assert.ok(get(`project-${page}-page`));assert.equal(d.documentElement.classList.contains('dark'),theme==='dark');assert.equal(d.querySelector('[role="dialog"]'),null);
   // 窄屏列表视图仍保留 Project 切换入口，与桌面侧栏顶部同一个组件语义。
   if(width===390){await click('mobile-nav-projects');await click('mobile-project-nav-chats');assert.ok(get('chat-list'));assert.ok(get('list-project-selector'));await click('mobile-nav-projects');await click(page==='members'?'mobile-project-nav-settings':'mobile-project-nav-members');assert.ok(get(`project-${page==='members'?'settings':'members'}-page`));assert.equal(d.querySelector('[role="dialog"]'),null);assert.equal(get('mobile-list-bar'),null)}
   assert.equal(errors.length,0,errors.join('\n'));
  }finally{dom.window.close()}
 }
});
test('Members 的 Agent 行可点开 profile，Human 行不可点且返回指回 Members',async()=>{
 const {dom,w,d,get,click,errors}=await mount('members');
 try{
  // Human 没有 profile 页面，不能做成看起来可点击的链接。
  assert.equal(get('member-human').querySelector('a'),null);assert.equal(get('member-human').classList.contains('has-link'),false);
  for(const id of ['amenda','wenxu','zhiheng']){
   assert.ok(get('member-'+id).classList.contains('has-link'));
   assert.equal(get('member-profile-'+id).getAttribute('href'),'#/agents/'+id);
   // 移除按钮必须留在链接之外，否则按「卡片任意处」点开会误触发移除确认。
   assert.equal(get('member-'+id).querySelector('.project-member-meta a:not([data-od-id])'),null);
  }
  await click('member-profile-wenxu');
  assert.equal(w.location.hash,'#/agents/wenxu');assert.ok(get('agent-detail-page'));
  assert.equal(get('page-back').getAttribute('href'),'#/projects/sprout-refactor/members');assert.match(get('page-back').textContent,/返回 Members/);
  await click('page-back');assert.ok(get('project-members-page'));
  // 直接从 Agents 列表进入时，返回仍指向 Agents，不沿用上一次的 Members 来源。
  w.location.hash='#/agents';await wait();await click('agent-card-wenxu');
  assert.equal(get('agent-detail-page')!==null,true);assert.equal(get('page-back').getAttribute('href'),'#/agents');
  assert.equal(errors.length,0,errors.join('\n'));
 }finally{dom.window.close()}
});
test('宿主屏蔽 hashchange 时，指向 profile 的链接仍能切换页面',async()=>{
 // 预览宿主常把产物注入 srcdoc/sandbox iframe：location.hash 可能写不进去，hashchange 也就
 // 不会触发。路由必须由脚本直接写入 state；只靠 URL 驱动的链接会表现为“点不动”。
 const errors=[],vc=new VirtualConsole();vc.on('jsdomError',e=>errors.push(e.message));
 const dom=new JSDOM(html,{url:'http://localhost/sprout-mio.html#/projects/sprout-refactor/members',runScripts:'dangerously',pretendToBeVisual:true,virtualConsole:vc,beforeParse(w){
  Object.defineProperty(w,'innerWidth',{value:1440});
  w.addEventListener('hashchange',e=>e.stopImmediatePropagation(),true);
 }});
 const w=dom.window,d=w.document;
 try{
  for(let i=0;i<40&&!d.querySelector('[data-od-id="workspace-shell"]');i++)await wait();
  const get=id=>d.querySelector(`[data-od-id="${id}"]`);
  const press=async id=>{const el=get(id);assert.ok(el,`缺少入口 ${id}`);el.dispatchEvent(new w.MouseEvent('click',{bubbles:true,cancelable:true,button:0}));await wait()};
  assert.ok(get('project-members-page'));
  await press('member-profile-wenxu');
  assert.ok(get('agent-detail-page'),'Members 里的 Agent 行必须能打开 profile');
  assert.equal(get('agent-detail-page').querySelector('h1').textContent,'闻序');
  assert.equal(w.location.hash,'#/agents/wenxu','链接语义仍是 URL 可定位的');
  // 从 Members 进入时返回 Members，而不是回到 Agents 列表。
  await press('page-back');assert.ok(get('project-members-page'));
  // Agents 列表页的入口同样成立。
  await press('nav-agents');assert.ok(get('agents-page'));
  await press('agent-card-wenxu');assert.ok(get('agent-detail-page'));
  // Project 选择器同样不能只靠写 URL：否则在沙箱宿主里“切换 Project”会毫无反应。
  await press('sidebar-project-selector-trigger');await press('create-local-project');
  const nameInput=get('create-project-name');Object.getOwnPropertyDescriptor(w.HTMLInputElement.prototype,'value').set.call(nameInput,'第二项目');nameInput.dispatchEvent(new w.Event('input',{bubbles:true}));
  get('create-project-form').dispatchEvent(new w.Event('submit',{bubbles:true,cancelable:true}));
  for(let i=0;i<20&&!get('chat-list');i++)await wait(60);
  // 详情页已并入 Settings：新建 Project 后直接落到它的 Chats。
  assert.ok(get('chat-list'),'新建 Project 后必须真正切换到它');
  assert.match(w.location.hash,/#\/projects\/local-project-\d+\/chats$/);
  await press('sidebar-project-selector-trigger');await press('project-option-sprout-mio');await wait(60);
  assert.equal(w.location.hash,'#/projects/sprout-refactor/chats');
  assert.match(get('sidebar-project-selector-trigger').textContent,/Sprout Mio 重构/);
  assert.equal(errors.length,0,errors.join('\n'));
 }finally{w.close()}
});
test('宿主提前 preventDefault 或拦下 hashchange 时，链接仍然由脚本接管',async()=>{
 // 预览宿主可能对全部链接做 preventDefault（防止整页导航）。此时旧实现会因为
 // defaultPrevented 直接放弃接管，界面看起来就是“点不动”。两种干涉同时施加，验证覆盖。
 const errors=[],vc=new VirtualConsole();vc.on('jsdomError',e=>errors.push(e.message));
 const dom=new JSDOM(html,{url:'http://localhost/sprout-mio.html#/projects/sprout-refactor/members',runScripts:'dangerously',pretendToBeVisual:true,virtualConsole:vc,beforeParse(w){
  Object.defineProperty(w,'innerWidth',{value:1440});
  w.addEventListener('click',e=>{if(e.target?.closest?.('a[href^="#"]'))e.preventDefault()},true);
  w.addEventListener('hashchange',e=>e.stopImmediatePropagation(),true);
 }});
 const w=dom.window,d=w.document;
 try{
  for(let i=0;i<40&&!d.querySelector('[data-od-id="workspace-shell"]');i++)await wait();
  const get=id=>d.querySelector(`[data-od-id="${id}"]`);
  const press=async id=>{const el=get(id);assert.ok(el,`缺少入口 ${id}`);el.dispatchEvent(new w.MouseEvent('click',{bubbles:true,cancelable:true,button:0}));await wait()};
  await press('member-profile-wenxu');
  assert.ok(get('agent-detail-page'),'已被 preventDefault 的链接仍需完成页面切换');
  await press('nav-agents');await press('agent-card-wenxu');
  assert.ok(get('agent-detail-page'));
  assert.equal(errors.length,0,errors.join('\n'));
 }finally{w.close()}
});

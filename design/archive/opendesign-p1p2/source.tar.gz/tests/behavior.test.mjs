import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {JSDOM,VirtualConsole} from 'jsdom';
import {createThread,threadReducer,parseRoute,routeFor} from '../src/model.mjs';
const wait=ms=>new Promise(r=>setTimeout(r,ms));
async function mount(file='sprout-mio.html',url='http://localhost/sprout-mio.html',width=1440,storage={}){
 const errors=[];const vc=new VirtualConsole();vc.on('jsdomError',e=>errors.push(e.message));
 const dom=new JSDOM(await readFile(new URL('../'+file,import.meta.url),'utf8'),{url,runScripts:'dangerously',pretendToBeVisual:true,virtualConsole:vc,beforeParse(w){for(const[key,value]of Object.entries(storage))w.localStorage.setItem(key,value);Object.defineProperty(w,'innerWidth',{value:width,writable:true});const viewport=new w.EventTarget();viewport.height=844;Object.defineProperty(w,'visualViewport',{value:viewport})}});
 await wait(60);return {dom,w:dom.window,d:dom.window.document,errors};
}
const click=(w,node)=>node.dispatchEvent(new w.MouseEvent('click',{bubbles:true}));
function enter(w,el,text){const proto=el.tagName==='TEXTAREA'?w.HTMLTextAreaElement.prototype:w.HTMLInputElement.prototype;Object.getOwnPropertyDescriptor(proto,'value').set.call(el,text);el.dispatchEvent(new w.Event('input',{bubbles:true}));}

test('收起侧栏后仍可切换 Project、导航和主题，保留草稿并按新空间调整 Info Hub',async()=>{
 const storage={'sprout:info-hub-width':'480'};
 const {dom,w,d,errors}=await mount('sprout-mio.html','http://localhost/sprout-mio.html'+routeFor('architecture',true),1440,storage);
 const get=id=>d.querySelector(`[data-od-id="${id}"]`);
 try{
  enter(w,get('message-input'),'收起后继续核对分析依据');await wait(30);
  assert.equal(get('resize-info-hub').getAttribute('aria-valuenow'),'408');
  click(w,get('toggle-sidebar'));await wait(30);
  assert.equal(get('toggle-sidebar').getAttribute('aria-expanded'),'false');
  assert.ok(get('workspace-shell').classList.contains('sidebar-collapsed'));
  assert.equal(w.localStorage.getItem('sprout:sidebar-collapsed'),'true');
  assert.equal(get('resize-info-hub').getAttribute('aria-valuenow'),'480','释放的侧栏空间应纳入 Info Hub 上限');
  assert.equal(get('project-submenu').hidden,false);
  for(const id of ['project-chats','project-members','project-settings','nav-agents'])assert.ok(get(id).getAttribute('aria-label'));
  assert.equal(get('toggle-inspector').previousElementSibling,get('theme-toggle'));
  click(w,get('theme-toggle'));await wait(30);assert.ok(d.documentElement.classList.contains('dark'));
  click(w,get('sidebar-project-selector-trigger'));await wait(30);assert.ok(get('sidebar-project-selector-popover'));
  click(w,get('project-option-sprout-mio'));await wait(30);assert.equal(get('sidebar-project-selector-popover'),null);
  click(w,get('project-members'));await wait(30);assert.ok(get('project-members-page'));assert.ok(get('theme-toggle'));
  assert.equal(d.querySelectorAll('[data-od-id="sidebar-menu"] [aria-current="page"]').length,1);
  click(w,get('project-chats'));await wait(30);click(w,get('chat-architecture'));await wait(30);
  assert.equal(get('message-input').value,'收起后继续核对分析依据');
  click(w,get('account-menu'));await wait(30);assert.ok(get('account-popover').classList.contains('account-menu-compact'));
  click(w,get('account-menu'));await wait(30);
  click(w,get('toggle-sidebar'));await wait(30);assert.equal(get('toggle-sidebar').getAttribute('aria-expanded'),'true');
  assert.equal(get('workspace-shell').classList.contains('sidebar-collapsed'),false);assert.equal(w.localStorage.getItem('sprout:sidebar-collapsed'),'false');
  assert.equal(get('message-input').value,'收起后继续核对分析依据');assert.equal(errors.length,0,errors.join('\n'));
 }finally{dom.window.close()}
 const restored=await mount('sprout-mio.html','http://localhost/sprout-mio.html'+routeFor('architecture'),1440,{'sprout:sidebar-collapsed':'true'});
 try{
  const get=id=>restored.d.querySelector(`[data-od-id="${id}"]`);
  assert.ok(get('workspace-shell').classList.contains('sidebar-collapsed'));assert.equal(get('toggle-sidebar').getAttribute('aria-label'),'展开侧栏');
  restored.w.innerWidth=390;restored.w.dispatchEvent(new restored.w.Event('resize'));await wait(30);
  assert.equal(get('workspace-shell').classList.contains('sidebar-collapsed'),false,'移动布局不得继承图标窄栏样式');
  click(restored.w,get('back-to-list'));await wait(30);assert.ok(get('list-project-selector-trigger'));
  restored.w.innerWidth=1440;restored.w.dispatchEvent(new restored.w.Event('resize'));await wait(30);
  assert.ok(get('workspace-shell').classList.contains('sidebar-collapsed'),'回到桌面应恢复收起偏好');
 }finally{restored.dom.window.close()}
});

test('停止排队或运行中的 run 后，迟到的开始与完成事件都不能产生回复',()=>{
 for(const status of ['queued','running']){const original=createThread(status),stopped=threadReducer(original,{type:'stop'});let s=threadReducer(stopped,{type:'begin',generation:original.generation});s=threadReducer(s,{type:'complete',generation:original.generation,id:'late'});assert.equal(s.status,'stopped');assert.equal(s.messages.length,0);assert.equal(s.runSequence,original.runSequence);assert.ok(s.facts.includes('已停止，不会生成回复。'))}
});
test('运行中补充消息留在当前轮，新一轮才应用保存的 profile',()=>{
 const active=createThread('running');const appended=threadReducer(active,{type:'send',text:'补充证据',id:'m1',profileVersion:4,persona:'新摘要'});assert.equal(appended.generation,active.generation);assert.equal(appended.runSequence,active.runSequence);assert.equal(appended.profileVersion,3);assert.equal(appended.messages[0].appended,true);const next=threadReducer(threadReducer(appended,{type:'stop'}),{type:'send',text:'开始下一轮',id:'m2',profileVersion:4,persona:'新摘要'});assert.equal(next.status,'queued');assert.equal(next.profileVersion,4);assert.equal(next.persona,'新摘要');
});
test('重试创建新 run，旧 run 的迟到完成事件不能覆盖它',()=>{
 const failed=createThread('failed');const retried=threadReducer(failed,{type:'retry'});assert.equal(retried.runSequence,failed.runSequence+1);assert.equal(retried.status,'queued');const begun=threadReducer(retried,{type:'begin',generation:retried.generation});const old=threadReducer(begun,{type:'complete',generation:failed.generation,id:'old'});assert.equal(old.status,'running');assert.equal(old.messages.length,0);const done=threadReducer(old,{type:'complete',generation:retried.generation,id:'new'});assert.equal(done.status,'idle');assert.equal(done.messages.length,1);
});
test('列表、详情与 Info Hub 的 URL 可往返解析',()=>{
 for(const [id,info] of [[null,false],['architecture',false],['architecture',true]])assert.deepEqual(parseRoute(routeFor(id,info)),{id,info});
});
test('嵌入式无源页面也能启动工作台并停止 run',async()=>{
 const {dom,w,d,errors}=await mount('sprout-mio.html','about:blank');try{assert.ok(d.querySelector('[data-od-id="workspace-shell"]'),'嵌入式页面应有真实界面');click(w,d.querySelector('[data-od-id="stop-run"]'));await wait(30);assert.match(d.body.textContent,/已停止，不会生成回复/);assert.equal(d.querySelector('[data-od-id="active-run"]'),null);assert.equal(errors.length,0,errors.join('\n'));}finally{dom.window.close()}
});
test('从零对话创建 DM 时不伪造历史消息',async()=>{
 const {dom,w,d}=await mount('sprout-mio.html','http://localhost/sprout-mio.html?state=empty#/projects/sprout-refactor/chats');try{click(w,d.querySelector('[data-od-id="new-chat"]'));await wait(20);enter(w,d.querySelector('#new-title'),'接口边界复核');await wait(20);d.querySelector('.modal form').dispatchEvent(new w.Event('submit',{bubbles:true,cancelable:true}));await wait(40);assert.match(d.querySelector('[data-od-id="chat-title"]').textContent,/接口边界复核/);assert.equal(d.querySelector('[data-od-id="human-question"]'),null);assert.match(d.querySelector('[data-od-id="message-history"]').textContent,/开始 Chat/)}finally{dom.window.close()}
});
test('移动端 Info Hub 是可返回的独立页面，往返保留草稿与 run，软键盘收缩更新高度',async()=>{
 const {dom,w,d}=await mount('sprout-mio.html','http://localhost/sprout-mio.html#/projects/sprout-refactor/chats',390);
 const get=id=>d.querySelector(`[data-od-id="${id}"]`);
 try{
  click(w,get('chat-architecture'));await wait(30);
  enter(w,get('message-input'),'返回后继续核对快照');await wait(30);
  const elapsed=Number(get('active-run').textContent.match(/(\d+)s$/)[1]);
  w.visualViewport.height=420;w.visualViewport.dispatchEvent(new w.Event('resize'));
  assert.equal(d.documentElement.style.getPropertyValue('--app-height'),'420px');
  click(w,get('toggle-inspector'));await wait(30);
  assert.equal(w.location.hash,routeFor('architecture',true));
  assert.equal(get('info-hub').getAttribute('role'),'region');
  assert.equal(get('resize-info-hub'),null,'移动端独立页面不应出现桌面拖动手柄');
  assert.equal(get('info-hub').hasAttribute('aria-modal'),false);
  assert.equal(d.querySelector('.drawer-backdrop'),null);
  assert.equal(get('chat-pane').hasAttribute('inert'),true);
  assert.match(get('close-inspector').getAttribute('aria-label'),/返回聊天/);
  click(w,get('close-inspector'));await wait(30);
  assert.equal(w.location.hash,routeFor('architecture'));
  assert.equal(get('message-input').value,'返回后继续核对快照');
  assert.match(get('active-run').textContent,/正在梳理上下文边界/);
  assert.ok(Number(get('active-run').textContent.match(/(\d+)s$/)[1])>=elapsed,'返回后 run 继续计时，不应重新开始');
  assert.equal(get('chat-pane').hasAttribute('inert'),false);
  click(w,get('toggle-inspector'));await wait(30);w.history.back();await wait(60);
  assert.equal(w.location.hash,routeFor('architecture'));
  w.history.forward();await wait(60);assert.ok(get('info-hub'));
  w.innerWidth=1024;w.dispatchEvent(new w.Event('resize'));await wait(30);
  assert.equal(get('info-hub').tagName,'ASIDE');assert.equal(get('chat-pane').hasAttribute('inert'),false);
  click(w,get('close-inspector'));await wait(30);click(w,get('back-to-list'));await wait(30);
  assert.equal(w.location.hash,routeFor());
 }finally{dom.window.close()}
});
test('桌面 Info Hub 是并排侧栏，可收起且不锁定聊天焦点；移动直达链接可返回聊天',async()=>{
 // jsdom 不执行布局：额外守住侧栏不再脱离文档流的约束。
 const html=await readFile(new URL('../sprout-mio.html',import.meta.url),'utf8');
 const css=html.slice(html.indexOf('<style>'),html.indexOf('</style>'));
 const inspectorRules=[...css.matchAll(/\.inspector\{([^}]+)\}/g)];
 assert.ok(inspectorRules.length);
 for(const [,rule]of inspectorRules){assert.doesNotMatch(rule,/position:(absolute|fixed)/);assert.doesNotMatch(rule,/box-shadow:/)}
 for(const width of [1024,1440,390]){
  const {dom,w,d,errors}=await mount('sprout-mio.html','http://localhost/sprout-mio.html'+routeFor('architecture',true),width);
  const get=id=>d.querySelector(`[data-od-id="${id}"]`);
  try{
   assert.equal(get('info-hub').hasAttribute('aria-modal'),false);assert.equal(d.querySelector('.drawer-backdrop'),null);
   assert.equal(get('info-hub').tagName,width<=900?'SECTION':'ASIDE');
   if(width>900){const last=[...get('info-hub').querySelectorAll('button,summary')].at(-1);last.focus();const tab=new w.KeyboardEvent('keydown',{key:'Tab',bubbles:true,cancelable:true});last.dispatchEvent(tab);assert.equal(tab.defaultPrevented,false,'侧栏不应循环捕获 Tab');get('message-input').focus();assert.equal(d.activeElement,get('message-input'))}
   click(w,get('close-inspector'));await wait(35);
   assert.equal(w.location.hash,routeFor('architecture'));assert.equal(get('info-hub'),null);
   assert.ok(get('message-input'));assert.equal(errors.length,0,errors.join('\n'));
  }finally{dom.window.close()}
 }
});
test('Info Hub 拖动与键盘调宽有边界，收起或刷新后恢复偏好，窗口缩小时保留列表和偏好',async()=>{
 const {dom,w,d,errors}=await mount('sprout-mio.html','http://localhost/sprout-mio.html'+routeFor('architecture',true),1920);
 const get=id=>d.querySelector(`[data-od-id="${id}"]`);
 const width=()=>Number(get('resize-info-hub').getAttribute('aria-valuenow'));
 const pointer=(target,type,x)=>{const event=new w.MouseEvent(type,{bubbles:true,cancelable:true,clientX:x,button:0});Object.defineProperty(event,'pointerId',{value:1});target.dispatchEvent(event)};
 let saved;
 try{
  assert.equal(width(),320);
  pointer(get('resize-info-hub'),'pointerdown',1600);pointer(w,'pointermove',1500);await wait(25);assert.equal(width(),420);
  pointer(w,'pointermove',900);await wait(25);assert.equal(width(),480);
  pointer(w,'pointermove',1800);await wait(25);assert.equal(width(),240);
  pointer(w,'pointerup',1800);pointer(w,'pointermove',1400);await wait(25);assert.equal(width(),240);assert.equal(d.body.classList.contains('resizing-inspector'),false);
  get('resize-info-hub').dispatchEvent(new w.KeyboardEvent('keydown',{key:'ArrowLeft',bubbles:true,cancelable:true}));await wait(25);assert.equal(width(),256);
  get('resize-info-hub').dispatchEvent(new w.MouseEvent('dblclick',{bubbles:true}));await wait(25);assert.equal(width(),320);
  pointer(get('resize-info-hub'),'pointerdown',1600);pointer(w,'pointermove',1520);await wait(25);assert.equal(width(),400);
  click(w,get('close-inspector'));await wait(25);assert.equal(d.body.classList.contains('resizing-inspector'),false);
  click(w,get('toggle-inspector'));await wait(25);assert.equal(width(),400);
  pointer(w,'pointermove',1200);await wait(25);assert.equal(width(),400,'已卸载的拖动手柄不得继续处理指针');
  // 1024px 打开 Info Hub 时侧栏收成 64px、列表压到 184px，上限按剩余空间重算为 315。
  w.innerWidth=1024;w.dispatchEvent(new w.Event('resize'));await wait(25);assert.equal(width(),315);assert.ok(get('chat-list'));assert.equal(d.querySelector('[data-od-id="workspace-shell"]').classList.contains('sidebar-collapsed'),true);assert.equal(get('chat-list').hasAttribute('inert'),false);
  w.innerWidth=1920;w.dispatchEvent(new w.Event('resize'));await wait(25);assert.equal(width(),400);
  assert.equal(d.querySelector('.workspace-grid').style.getPropertyValue('--inspector-width'),'400px');
  saved=w.localStorage.getItem('sprout:info-hub-width');assert.equal(saved,'400');assert.equal(errors.length,0,errors.join('\n'));
 }finally{dom.window.close()}
 const restored=await mount('sprout-mio.html','http://localhost/sprout-mio.html'+routeFor('architecture',true),1920,{'sprout:info-hub-width':saved});
 try{assert.equal(restored.d.querySelector('[data-od-id="resize-info-hub"]').getAttribute('aria-valuenow'),'400')}finally{restored.dom.window.close()}
});

test('失败态能追踪 requestId，重试进入新一轮排队',async()=>{
 const {dom,w,d}=await mount('sprout-mio.html','http://localhost/sprout-mio.html?state=failed#/projects/sprout-refactor/chats/architecture/info');try{assert.match(d.querySelector('[data-od-id="run-error"]').textContent,/UPSTREAM_TIMEOUT/);assert.match(d.body.textContent,/宿主重启，上一轮已中断/);click(w,d.querySelector('[data-od-id="error-request-id"]'));await wait(20);assert.match(d.querySelector('[role="dialog"]').textContent,/req_sm_0618_8f31/);click(w,d.querySelector('[data-od-id="close-dialog"]'));await wait(20);click(w,d.querySelector('[data-od-id="retry-run"]'));await wait(25);assert.match(d.querySelector('[data-od-id="active-run"]').textContent,/等待运行资源/);assert.equal(d.querySelector('[data-od-id="run-error"]'),null);click(w,d.querySelector('[data-od-id="stop-run"]'));await wait(20);assert.match(d.body.textContent,/已停止，不会生成回复/);}finally{dom.window.close()}
});
test('profile 编辑在下一轮生效，历史人设说明保持原样',async()=>{
 const {dom,w,d}=await mount('sprout-mio.html','http://localhost/sprout-mio.html#/projects/sprout-refactor/chats/architecture/info');try{click(w,d.querySelector('[data-od-id="profile-details"] summary'));click(w,d.querySelector('[data-od-id="edit-profile"]'));await wait(20);enter(w,d.querySelector('#profile-persona'),'逐项核对边界，保留可复现的分析依据。');await wait(20);click(w,d.querySelector('[data-od-id="save-profile"]'));await wait(25);assert.match(d.querySelector('[data-od-id="profile-context"]').textContent,/profile v3/);assert.match(d.querySelector('[data-od-id="profile-context"]').textContent,/待生效/);click(w,d.querySelector('[data-od-id="stop-run"]'));await wait(20);enter(w,d.querySelector('#message-draft'),'按新 profile 开始一轮。');await wait(20);click(w,d.querySelector('[data-od-id="send-message"]'));await wait(30);assert.match(d.querySelector('[data-od-id="profile-context"]').textContent,/profile v4/);assert.match(d.querySelector('[data-od-id="agent-analysis"] .persona').textContent,/先证据，后结论/);}finally{dom.window.close()}
});
test('登录校验给出具体错误与 requestId，并能切换注册',async()=>{
 const {dom,w,d}=await mount('sprout-login.html','http://localhost/sprout-login.html');try{d.querySelector('form').dispatchEvent(new w.Event('submit',{bubbles:true,cancelable:true}));await wait(20);assert.match(d.querySelector('[role="alert"]').textContent,/有效的邮箱/);assert.match(d.querySelector('[role="alert"]').textContent,/requestId/);click(w,d.querySelector('[data-od-id="register-tab"]'));await wait(20);assert.match(d.querySelector('h1').textContent,/创建工作空间/)}finally{dom.window.close()}
});

test('窄屏列表顶栏的 display 只存在于窄屏断点内，宽屏不显示',async()=>{
 const html=await readFile(new URL('../sprout-mio.html',import.meta.url),'utf8');
 const css=html.slice(html.indexOf('<style>'),html.indexOf('</style>'));
 const at=[];let i=-1;
 while((i=css.indexOf('.mobile-list-bar{',i+1))>=0){
   const before=css.slice(0,i);
   const open=before.lastIndexOf('@media');
   const depth=before.split('{').length-before.split('}').length;
   at.push(open<0||depth===0?null:before.slice(open).split('{')[0].trim());
 }
 assert.ok(at.length,'应存在 .mobile-list-bar 样式');
 for(const media of at)assert.match(String(media),/^@media \(max-width:\d+px\)$/,`宽屏下会漏出窄屏顶栏：${media}`);
});

test('Project 内导航菜单项为横排，且不被未分层的竖排规则覆盖',async()=>{
 const html=await readFile(new URL('../sprout-mio.html',import.meta.url),'utf8');
 const css=html.slice(html.indexOf('<style>'),html.indexOf('</style>'));
 const layers=[];let at=-1;
 while((at=css.indexOf('@layer',at+1))>=0){
  const brace=css.indexOf('{',at),stop=css.indexOf(';',at);
  if(stop>=0&&(brace<0||stop<brace))continue;
  let depth=0,end=brace;
  for(;end<css.length;end++){if(css[end]==='{')depth++;else if(css[end]==='}'){depth--;if(depth===0)break}}
  layers.push([at,end]);
 }
 const i=css.indexOf('.mobile-primary-nav .project-nav-panel button{');
 assert.ok(i>=0,'应存在 Project 内导航菜单项样式');
 assert.ok(!layers.some(([s,e])=>i>s&&i<e),'菜单项样式落在 @layer 内，会被未分层的竖排规则覆盖');
 assert.match(css.slice(i,i+240),/flex-(?:direction:row|flow:row)/);
});
test('未读点使用高亮强调色 primary，而不是警告色或纯前景色',async()=>{
 const html=await readFile(new URL('../sprout-components.html',import.meta.url),'utf8');
 const css=html.slice(html.indexOf('<style>'),html.indexOf('</style>'));
 const i=css.indexOf('.unread-dot{');
 assert.ok(i>=0,'应存在未读点样式');
 const rule=css.slice(i,css.indexOf('}',i)+1);
 assert.match(rule,/background:var\(--primary\)/,'未读点是高亮标记，应绑定 --primary');
 assert.doesNotMatch(rule,/status-warning/,'未读不是警告语义');
});
test('窄屏输入框字号跟随消息正文，16px 只作为 iOS 防缩放兜底',async()=>{
 const css=await readFile(new URL('../src/app.css',import.meta.url),'utf8');
 const rules=[...css.matchAll(/\.composer textarea\s*\{([^}]*)\}/g)].map(m=>({body:m[1],before:css.slice(0,m.index)}));
 const mobile=rules.find(r=>/height:48px/.test(r.body));
 assert.ok(mobile,'应存在窄屏输入框样式');
 assert.match(mobile.body,/font-size:13px/,'窄屏输入框字号应与消息正文一致（13px）');
 for(const rule of rules.filter(r=>/font-size:16px/.test(r.body))){
  assert.match(rule.before.slice(-200),/@supports \(-webkit-touch-callout: ?none\)/,'16px 只允许出现在 iOS 防缩放兜底里');
 }
});

test('窄桌面打开 Info Hub 自动把侧栏收成图标栏，列表保留并压窄',async()=>{
 const html=await readFile(new URL('../sprout-mio.html',import.meta.url),'utf8');
 const css=html.slice(html.indexOf('<style>'),html.indexOf('</style>'));
 for(const [width,rail] of [[901,true],[1024,true],[1199,true],[1200,false],[1440,false]]){
  const {dom,w,d,errors}=await mount('sprout-mio.html','http://localhost/sprout-mio.html'+routeFor('architecture',true),width);
  try{
   const grid=d.querySelector('.workspace-grid');
   assert.equal(d.querySelector('[data-od-id="workspace-shell"]').classList.contains('sidebar-collapsed'),rail,`${width}px 的侧栏应收成图标栏`);
   assert.equal(grid.classList.contains('list-hidden'),false,'列表列不再被隐藏');
   const list=d.querySelector('[data-od-id="chat-list"]');
   assert.equal(list.hasAttribute('inert'),false,`${width}px 的列表必须可操作`);
   assert.equal(d.querySelector('[data-od-id="back-to-list"]').classList.contains('list-return'),false,`${width}px 桌面不出现返回列表箭头`);
   assert.equal(grid.classList.contains('rail-hub'),rail,`${width}px 的列表列应知道自己在让位`);
   // 列表列让位时压到 160–220px，规则强度由 CSS 断言守住（jsdom 不做布局）。
   assert.match(css,/\.workspace-grid\.rail-hub\{grid-template-columns:clamp\(160px,18vw,220px\)\s*minmax\(0,1fr\)\s*var\(--inspector-width,320px\)\}/);
   assert.match(css,/@media \(min-width:901px\) and \(max-width:1199px\)\{[^@]*\.workspace-grid\.rail-hub\{grid-template-columns:clamp\(160px,18vw,220px\)/);
   assert.equal(d.querySelector('[data-od-id="chat-search"]').placeholder,rail?'搜索':'搜索 Chat...',`${width}px 的搜索提示随列宽收短`);
   // 筛选行在列表压窄时隐藏；隐藏的控件不得继续生效，列表展示全部类型。
   assert.equal(!!d.querySelector('.filter-tabs'),!rail,`${width}px 的筛选行可见性`);
   assert.equal(d.querySelectorAll('.chat-item').length,rail?7:5,`${width}px 的列表应展示${rail?'全部':'DM'}会话`);
   assert.match(d.querySelector('.list-label').textContent,rail?/全部对话/:/最近对话/,`${width}px 的列表标题`);
   // 上限按真实列宽推导：视口 - 侧栏 - 列表 - 聊天保底，再夹到 240–480。
   const sidebar=rail?64:200;
   const listCol=rail?Math.max(160,Math.min(width*0.18,220)):width>=1360?272:Math.max(220,Math.min(width*0.2,272));
   const floor=width>=1200?560:460;
   const expected=Math.max(240,Math.min(480,Math.floor(width-sidebar-listCol-floor)));
   assert.equal(Number(d.querySelector('[data-od-id="resize-info-hub"]').getAttribute('aria-valuemax')),expected,`${width}px 的 Info Hub 上限按列宽重算`);
   assert.equal(errors.length,0,errors.join('\n'));
  }finally{dom.window.close()}
 }
});
test('脚本聚焦的内容锚点不画焦点环',async()=>{
 const html=await readFile(new URL('../sprout-mio.html',import.meta.url),'utf8');
 const css=html.slice(html.indexOf('<style>'),html.indexOf('</style>'));
 assert.match(css,/:focus-visible\{outline:2px solid var\(--ring\)/,'控件仍需可见的键盘焦点环');
 assert.match(css,/\[tabindex="-1"\]:focus-visible\{outline:none\}/,'深链聚焦的标题不应出现方框');
});
test('登录页不设独立顶栏，品牌与主题切换并入表单',async()=>{
 const {dom,w,d,errors}=await mount('sprout-login.html','http://localhost/sprout-login.html');
 try{
  assert.equal(d.querySelector('.auth-header'),null,'登录页不应有脱离内容的顶栏');
  const row=d.querySelector('.auth-brand-row');
  assert.ok(row,'品牌行应在表单区块内');
  assert.ok(row.closest('form'));
  assert.ok(row.querySelector('[data-od-id="theme-toggle"]'),'主题切换随品牌行一起移入表单');
  assert.equal(errors.length,0,errors.join('\n'));
 }finally{dom.window.close()}
});

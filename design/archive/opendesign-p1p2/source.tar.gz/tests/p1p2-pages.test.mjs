import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {JSDOM,VirtualConsole} from 'jsdom';
const html=await readFile(new URL('../sprout-mio.html',import.meta.url),'utf8');
const pause=ms=>new Promise(resolve=>setTimeout(resolve,ms));
async function mount(hash='#/projects',options={}){
 const errors=[],vc=new VirtualConsole();vc.on('jsdomError',error=>errors.push(error.message));
 const dom=new JSDOM(html,{url:'http://localhost/sprout-mio.html'+(options.query||'')+hash,runScripts:'dangerously',pretendToBeVisual:true,virtualConsole:vc,beforeParse(w){Object.defineProperty(w,'innerWidth',{value:options.width||1440,writable:true});if(options.snapshot)w.sessionStorage.setItem('sprout:p1p2',options.snapshot)}});
 const w=dom.window,d=w.document,get=id=>d.querySelector(`[data-od-id="${id}"]`);
 const until=async predicate=>{for(let i=0;i<120;i++){if(predicate())return;await pause(20)}assert.ok(predicate(),'界面未在时限内进入预期状态')};
 await until(()=>get('workspace-shell'));
 const click=async id=>{assert.ok(get(id),'缺少 '+id);get(id).click();await pause(40)};
 const enter=async(id,value)=>{const el=get(id);assert.ok(el,'缺少 '+id);const proto=el.tagName==='SELECT'?w.HTMLSelectElement.prototype:el.tagName==='TEXTAREA'?w.HTMLTextAreaElement.prototype:w.HTMLInputElement.prototype;Object.getOwnPropertyDescriptor(proto,'value').set.call(el,value);el.dispatchEvent(new w.Event(el.tagName==='SELECT'?'change':'input',{bubbles:true}));await pause(40)};
 const close=()=>{dom.window.close();assert.deepEqual(errors,[])};
 return {dom,w,d,get,until,click,enter,close,snapshot:()=>w.sessionStorage.getItem('sprout:p1p2')};
}
test('Projects 空态创建：空白校验、提交中防重与成功后的详情刷新',async()=>{
 const app=await mount('#/projects',{query:'?state=projects-empty',width:390});
 let createdHash,snapshot;
 try{
  assert.match(app.get('projects-page').textContent,/还没有 Project/);assert.equal(app.get('projects-list'),null);
  await app.click('create-project');await app.enter('create-project-name','   ');await app.click('submit-create-project');
  assert.match(app.d.querySelector('[role="alert"]').textContent,/不能为空/);assert.equal(app.get('create-project-form').getAttribute('aria-busy'),'false');
  await app.enter('create-project-name','新的协作');await app.click('submit-create-project');
  assert.equal(app.get('submit-create-project').disabled,true);assert.match(app.get('submit-create-project').textContent,/正在创建/);
  await app.until(()=>app.get('chat-list'));assert.equal(app.get('page-back'),null,'Chats 是主视图，不再有返回详情页的入口');
  createdHash=app.w.location.hash;snapshot=app.snapshot();assert.match(createdHash,/^#\/projects\/local-project-/);
  app.w.location.hash='#/projects';await app.until(()=>app.get('chat-list'));assert.ok(app.get('chat-list'),'只有一个 Project 时 /projects 直接落到 Chats');
 }finally{app.close()}
 const refreshed=await mount(createdHash,{snapshot,width:390});try{assert.ok(refreshed.get('chat-list'));assert.match(refreshed.get('sidebar-project-selector-trigger').textContent,/新的协作/)}finally{refreshed.close()}
});
test('创建失败与越权显示契约错误码和 requestId，重试前不会插入 Project',async()=>{
 // 零 Project 时列表页天然可见，不会触发分发——这正是「创建失败」需要的前提。
 const app=await mount('#/projects',{query:'?simulate=create-error&state=projects-empty'});
 try{
  assert.ok(app.get('projects-page'),'零 Project 时停在列表页');
  await app.click('create-project');await app.enter('create-project-name','失败后重试');
  for(const code of ['internal','forbidden']){
   await app.enter('demo-response',code);await app.click('submit-create-project');await app.until(()=>app.d.querySelector('[role="alert"]'));
   assert.match(app.d.querySelector('[role="alert"]').textContent,new RegExp(code+'.*requestId: req_demo_create'));
   assert.equal(app.get('create-project-name').value,'失败后重试');assert.equal(app.get('projects-list'),null,'失败不插入任何 Project');
  }
  await app.enter('demo-response','success');await app.click('submit-create-project');
  await app.until(()=>app.get('chat-list'));
  assert.equal(app.get('projects-page'),null,'成功后离开列表页');
 }finally{app.close()}
});
test('Project 详情并入设置：基本事实、成员与子页路由都可直达',async()=>{
 const app=await mount('#/projects/sprout-refactor/settings');
 try{
  // 详情页已删除：Project ID 与创建时间落在 Settings 的基本事实里。
  assert.ok(app.get('project-settings-page'));
  assert.match(app.get('project-settings-id').textContent,/sprout-refactor/);
  assert.ok(app.get('project-settings-created-at').textContent.trim());
  for(const [hash,target] of [['#/projects/sprout-refactor/members','project-members-page'],['#/projects/sprout-refactor/settings','project-settings-page'],['#/projects/sprout-refactor/chats','chat-list']]){
   app.w.location.hash=hash;await app.until(()=>app.get(target));
  }
  app.w.location.hash='#/projects/sprout-refactor/agents';await app.until(()=>app.get('project-members-page'));
  assert.equal(app.get('project-members-list').querySelectorAll('article').length,5);
 }finally{app.close()}
});
test('Agent 人设保存按下一轮生效，失败保留输入与版本，允许契约规定的空人设',async()=>{
 const app=await mount('#/agents/wenxu');let snapshot;
 try{
  assert.match(app.get('agent-version').textContent,/v3/);await app.enter('agent-persona','先复核调用边界，再给出结论。');
  await app.click('save-agent-persona');assert.equal(app.get('save-agent-persona').disabled,true);
  await app.until(()=>app.get('agent-save-feedback'));assert.match(app.get('agent-save-feedback').textContent,/已保存，下一轮生效/);assert.match(app.get('agent-version').textContent,/v4/);
  // 保存成功后 user 立刻输入下一版：先等提交中结束，再确认新草稿不会被已保存值回灌。
  await app.until(()=>app.get('agent-edit-form').getAttribute('aria-busy')==='false');await app.enter('agent-persona','失败时保留这份草稿');assert.equal(app.get('save-agent-persona').disabled,false,'修改人设后应允许再次保存');await app.enter('demo-response','internal');assert.equal(app.get('demo-response').value,'internal');await app.click('save-agent-persona');assert.equal(app.get('agent-edit-form').getAttribute('aria-busy'),'true','失败请求也应进入提交中');await app.until(()=>app.d.querySelector('[role="alert"]'));
  assert.match(app.d.querySelector('[role="alert"]').textContent,/internal.*requestId: req_demo_profile/);assert.equal(app.get('agent-save-feedback'),null);assert.match(app.get('agent-version').textContent,/v4/);assert.equal(app.get('agent-persona').value,'失败时保留这份草稿');
  await app.enter('demo-response','success');await app.enter('agent-persona','');await app.click('save-agent-persona');await app.until(()=>app.get('agent-save-feedback'));assert.match(app.get('agent-version').textContent,/v5/);
  // sessionStorage 由 effect 写入，保存反馈出现时可能还没落盘：先等到 v5 真正持久化再取快照。
  await app.until(()=>/"version":5/.test(app.snapshot()||''));snapshot=app.snapshot();
 }finally{app.close()}
 const refreshed=await mount('#/agents/wenxu',{snapshot});try{assert.equal(refreshed.get('agent-persona').value,'');assert.match(refreshed.get('agent-version').textContent,/v5/)}finally{refreshed.close()}
});
test('成员候选过滤已加入的 Agent，添加后候选为空，Human 无移除入口',async()=>{
 const app=await mount('#/projects/sprout-refactor/members',{width:390});
 try{
  assert.equal(app.get('member-human').querySelector('button'),null);
  await app.click('add-agent');assert.deepEqual([...app.get('add-agent-select').options].map(option=>option.value),['shiyan']);
  await app.click('confirm-member-mutation');assert.equal(app.get('confirm-member-mutation').disabled,true);await app.until(()=>!app.d.querySelector('[role="dialog"]'));
  assert.ok(app.get('member-shiyan'));assert.match(app.d.querySelector('[role="status"]').textContent,/已添加/);
  await app.click('add-agent');assert.equal(app.get('add-agent-select').disabled,true);assert.equal(app.get('confirm-member-mutation').disabled,true);assert.match(app.get('add-agent-select').textContent,/没有可添加/);
 }finally{app.close()}
});
test('移除需确认；取消、失败与越权均保留成员，成功后 profile 仍在全局列表',async()=>{
 const app=await mount('#/projects/sprout-refactor/members');
 try{
  await app.click('remove-member-wenxu');assert.match(app.d.querySelector('[role="dialog"]').textContent,/确认把「闻序」/);assert.ok(app.get('member-wenxu'));
  await app.click('cancel-member-mutation');assert.ok(app.get('member-wenxu'));assert.equal(app.d.querySelector('[role="dialog"]'),null);
  await app.click('remove-member-wenxu');
  for(const code of ['internal','forbidden']){
   await app.enter('demo-response',code);await app.click('confirm-member-mutation');await app.until(()=>app.d.querySelector('[role="alert"]'));
   assert.match(app.d.querySelector('[role="alert"]').textContent,new RegExp(code+'.*requestId: req_demo_member_remove'));assert.ok(app.get('member-wenxu'));
  }
  await app.enter('demo-response','success');await app.click('confirm-member-mutation');await app.until(()=>!app.d.querySelector('[role="dialog"]'));assert.equal(app.get('member-wenxu'),null);
  await app.click('add-agent');assert.deepEqual([...app.get('add-agent-select').options].map(option=>option.value),['wenxu','shiyan']);
  await app.click('cancel-member-mutation');await app.click('nav-agents');assert.ok(app.get('agent-card-wenxu'));
 }finally{app.close()}
});
test('重复添加与添加越权有明确反馈，失败不污染候选及成员集合',async()=>{
 const app=await mount('#/projects/sprout-refactor/members',{query:'?simulate=member-conflict'});
 try{
  await app.click('add-agent');
  for(const code of ['conflict','forbidden','internal']){
   await app.enter('demo-response',code);await app.click('confirm-member-mutation');await app.until(()=>app.d.querySelector('[role="alert"]'));
   assert.match(app.d.querySelector('[role="alert"]').textContent,new RegExp(code+'.*requestId: req_demo_member_add'));if(code==='conflict')assert.match(app.d.querySelector('[role="alert"]').textContent,/不能重复添加/);
   assert.equal(app.get('member-shiyan'),null);assert.equal(app.get('project-members-list').querySelectorAll('article').length,5);assert.equal(app.get('add-agent-select').value,'shiyan');
  }
 }finally{app.close()}
});
test('四块视图使用同一 URL 语义：桌面及 390px 直达、上一级、浏览器前后与刷新恢复',async()=>{
 // Project 详情已并入 Settings：#/projects/<id> 现在直接是 Chats，不再有独立的详情页。
 const cases=[['#/projects/sprout-refactor/settings','project-settings-page'],['#/agents','agents-page'],['#/agents/wenxu','agent-detail-page'],['#/projects/sprout-refactor/members','project-members-page']];
 for(const width of [1440,390])for(const [hash,id]of cases){
  const app=await mount(hash,{width,query:width===390?'?theme=dark':''});
  try{
   assert.ok(app.get(id));assert.ok(app.get('page-back'));assert.equal(app.d.querySelector('[role="dialog"]'),null);assert.equal(app.w.location.hash,hash);
   await app.click('page-back');assert.notEqual(app.w.location.hash,hash);app.w.history.back();await app.until(()=>app.w.location.hash===hash&&app.get(id));
   app.w.history.forward();await app.until(()=>app.w.location.hash!==hash&&!app.get(id));app.w.history.back();await app.until(()=>app.get(id));
   const refreshed=await mount(app.w.location.hash,{width,snapshot:app.snapshot()});try{assert.ok(refreshed.get(id))}finally{refreshed.close()}
  }finally{app.close()}
 }
});
// 只有一个 Project 时 #/projects 会分发到 Chats，列表页只在多 Project 时才有意义。
// 选择器不再提供「查看全部 Projects」，所以列表页只能靠「存在第二个 Project」达到。
async function createSecondProject(app,name='第二个协作'){
  await app.click('sidebar-project-selector-trigger');await app.until(()=>app.get('sidebar-project-selector-popover'));
  assert.equal(app.d.querySelector('a[href="#/projects"]'),null,'选择器不再提供列表入口');
  await app.click('create-local-project');
  await app.enter('create-project-name',name);
  await app.d.querySelector('[data-od-id="create-project-form"]').dispatchEvent(new app.w.Event('submit',{bubbles:true,cancelable:true}));
  // 判据是弹窗关闭（创建成功才关），而不是当前视图：本页可能本来就是 chat-list，
  // 且 ?simulate=create-error 下第一个 Project 会创建失败、hash 不变。
  await app.until(()=>!app.d.querySelector('[role="dialog"]'));
  return app.w.location.hash.split('/')[2];
}

test('Projects 列表的返回入口跟随当前 Project，而不是固定第一个',async()=>{
 const app=await mount('#/projects');
 try{
  const created=await createSecondProject(app);
  app.w.location.hash='#/projects/'+created+'/members';await app.until(()=>app.get('project-members-page'));
  // 侧栏 Projects 现在是二级菜单的折叠开关，不再导航；列表入口在 Project 选择器里。
  await app.click('nav-projects');assert.equal(app.get('projects-page'),null,'折叠开关不应导航');
  // 选择器里已无列表入口：直接访问 #/projects（此时已有两个 Project）。
  app.w.location.hash='#/projects';await app.until(()=>app.get('projects-page'));
  assert.equal(app.get('page-back').getAttribute('href'),`#/projects/${created}/chats`,'返回入口应指向当前 Project 的 Chats');
  assert.equal(app.get('projects-list').querySelectorAll('a').length,2);
 }finally{app.close()}
});
test('Project 间成员隔离，创建后零 Agent，切回原 Project 不丢成员',async()=>{
 const app=await mount('#/projects');
 try{
  const isolated=await createSecondProject(app,'独立 Project');
  app.w.location.hash='#/projects/'+isolated+'/members';await app.until(()=>app.get('project-members-page'));assert.equal(app.get('project-members-list').querySelectorAll('article').length,1);
  // 候选第一项是默认 Agent Amenda，添加它验证新 Project 从零成员变为一员。
  await app.click('add-agent');assert.equal(app.get('add-agent-select').options.length,5);assert.equal(app.get('add-agent-select').value,'amenda');await app.click('confirm-member-mutation');await app.until(()=>app.get('member-amenda'));
  app.w.location.hash='#/projects/sprout-refactor/members';await app.until(()=>app.get('member-zhiheng'));assert.equal(app.get('project-members-list').querySelectorAll('article').length,5);
 }finally{app.close()}
});
test('未知 Project 或 profile 深链不会显示其他实体的数据',async()=>{
 for(const [hash,id]of [['#/projects/missing','project-not-found'],['#/agents/missing','agent-not-found']]){
  const app=await mount(hash);try{assert.ok(app.get(id));assert.equal(app.get('agent-persona'),null);assert.ok(app.get('page-back'))}finally{app.close()}
 }
});
test('职位用于展示分工且可留空，model 与 effort 默认沿用宿主',async()=>{
 const app=await mount('#/agents/wenxu');
 try{
  assert.match(app.get('agent-detail-page').textContent,/架构审阅者/);
  assert.equal(app.get('agent-job-title').value,'架构审阅者');
  assert.equal(app.get('agent-model').value,'');
  assert.equal(app.get('agent-effort').value,'');
  assert.match(app.get('agent-model').options[0].textContent,/使用默认/);
  assert.match(app.get('agent-effort').options[0].textContent,/使用默认/);
  assert.equal(app.get('save-agent-persona').disabled,true,'未改动时不应允许保存');
  // 40 字上限由 maxLength 与校验共同保证：职位是展示字段，不承载任何权限语义。
  assert.equal(app.get('agent-job-title').getAttribute('maxlength'),'40');
  await app.enter('agent-job-title','');
  assert.equal(app.get('save-agent-persona').disabled,false,'职位可清空');
  await app.click('save-agent-persona');
  await app.until(()=>app.get('agent-save-feedback'));
  assert.equal(app.get('agent-job-title').value,'');
  assert.match(app.get('agent-detail-page').querySelector('h1').closest('header').textContent,/未设置职位/,'职位为空时不显示徽标，标题副行给出兜底');
 }finally{app.close()}
});
test('hash 链接由脚本接管，不依赖浏览器默认导航',async()=>{
 // OpenDesign 把产物注入 iframe 的 srcdoc 预览：此时 <a href=#/agents/x> 会被解析成
 // about:srcdoc 的整页导航并销毁文档，界面空白。应用必须自己接管同文档 hash 跳转。
 const app=await mount('#/agents');
 try{
  const card=app.get('agent-card-wenxu');
  assert.equal(card.tagName,'A','profile 入口是链接');
  assert.equal(card.getAttribute('href'),'#/agents/wenxu');
  const event=new app.w.MouseEvent('click',{bubbles:true,cancelable:true,button:0});
  card.dispatchEvent(event);
  assert.equal(event.defaultPrevented,true,'默认导航必须被拦截');
  await app.until(()=>app.get('agent-edit-form'));
  assert.equal(app.get('agents-page'),null);
  assert.ok(app.get('agent-job-title')&&app.get('agent-model')&&app.get('agent-effort'));
 }finally{app.close()}
});
test('移动端二级菜单与侧栏一致，不提供列表页入口',async()=>{
 // 列表页已不是导航目标：两侧菜单都只保留 Project 内的三个页面。
 for(const hash of ['#/projects/sprout-refactor/chats','#/projects/sprout-refactor/members','#/projects/sprout-refactor/settings']){
  const app=await mount(hash,{width:390});
  try{
   await app.click('mobile-nav-projects');
   await app.until(()=>app.get('mobile-project-submenu'));
   const labels=[...app.get('mobile-project-submenu').querySelectorAll('button,a')].map(el=>el.textContent.trim());
   assert.deepEqual(labels.map(text=>text.replace('当前页面','')),['Chats','Members','Project settings'],'二级菜单不应出现「全部 Projects」');
   assert.equal(app.get('mobile-project-submenu').querySelector('a[href="#/projects"]'),null);
   const current=[...app.get('mobile-project-submenu').querySelectorAll('[aria-current="page"]')];
   assert.equal(current.length,1,'当前页面必须且只能有一项');
   assert.match(current[0].textContent,new RegExp(hash.endsWith('chats')?'Chats':hash.endsWith('members')?'Members':'Project settings'));
  }finally{app.close()}
 }
});

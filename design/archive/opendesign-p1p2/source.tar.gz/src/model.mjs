export const profiles = [
  { id: 'amenda', name: 'Amenda', mark: 'A', jobTitle: '全能秘书', persona: '随和明快，说话简短。主动接住杂事，把待办和上下文整理清楚。需要判断的事先问，不替人做决定。' },
  { id: 'wenxu', name: '闻序', mark: '闻', jobTitle: '架构审阅者', persona: '先证据，后结论。关注系统边界与长期维护成本。' },
  { id: 'zhiheng', name: '知衡', mark: '知', jobTitle: '迁移规划者', persona: '拆解依赖，逐步迁移。每一步都保留回退路径。' },
  { id: 'jichuan', name: '纪川', mark: '纪', jobTitle: '质量复核者', persona: '沿用户路径复核，用可复现的事实描述风险。' },
];
export const chats = [
  { id:'architecture', title:'仓库首页架构评审', profile:'wenxu', type:'DM', time:'10:28', unread:true, summary:'闻序：建议将分析依据绑定到每次 run。', pinned:true },
  { id:'migration', title:'迁移计划讨论', profile:'zhiheng', type:'DM', time:'09:46', unread:true, summary:'知衡：先迁数据边界，再替换入口。' },
  { id:'p3-review', title:'P3 收尾复核', profile:'jichuan', type:'DM', time:'昨天', unread:false, summary:'纪川：错误恢复路径还需要补一轮复核。' },
  { id:'profile-scope', title:'profile 生效范围确认', profile:'wenxu', type:'DM', time:'昨天', unread:false, summary:'你：历史消息保留原 profile 版本。' },
  { id:'repo-source', title:'仓库来源与快照', profile:'zhiheng', type:'DM', time:'周一', unread:false, summary:'知衡：获取时点与 branch 一起记录。' },
  { id:'refactor-group', title:'重构方案联审', profile:'wenxu', type:'Group', time:'昨天', unread:false, summary:'纪川：恢复路径的验收条件已经对齐。' },
  { id:'public-notes', title:'重构决策记录', profile:'jichuan', type:'Public Channel', time:'周一', unread:false, summary:'闻序：已记录快照与证据引用的约定。' },
];
export const labels = {idle:'空闲',queued:'排队',running:'运行中',stopped:'已停止',failed:'失败',unknown:'未知',interrupted:'已中断',unimplemented:'未实现'};
export function createThread(status='idle') { return {status, elapsed:42, generation:1, runSequence:1, profileVersion:3, persona:null, auto:false, messages:[], facts:[], retryCount:0}; }
export function threadReducer(state, action) {
  if (action.type==='send') {
    if (!action.text.trim()) return state;
    const active=['running','queued'].includes(state.status);
    return {...state, messages:[...state.messages,{id:action.id,text:action.text,role:'human',appended:active}],status:active?state.status:'queued',auto:active?state.auto:true,generation:active?state.generation:state.generation+1,runSequence:active?state.runSequence:state.runSequence+1,profileVersion:active?state.profileVersion:action.profileVersion||state.profileVersion,persona:active?state.persona:action.persona??state.persona,elapsed:active?state.elapsed:0,facts:[...state.facts,active?'补充消息已追加到当前轮。':'消息已投递，run 已排队。']};
  }
  if(action.type==='stop') {
    if(!['running','queued'].includes(state.status))return state;
    return {...state,status:'stopped',auto:false,generation:state.generation+1,facts:[...state.facts,'已停止，不会生成回复。']};
  }
  if(action.type==='retry')return {...state,status:'queued',auto:true,generation:state.generation+1,runSequence:state.runSequence+1,elapsed:0,retryCount:state.retryCount+1,facts:[...state.facts,'已保留原消息，以相同上下文重试。']};
  if(action.type==='begin' && action.generation===state.generation && state.status==='queued')return {...state,status:'running'};
  if(action.type==='complete' && action.generation===state.generation && state.status==='running')return {...state,status:'idle',auto:false,messages:[...state.messages,{id:action.id,role:'agent',persona:state.persona,profileVersion:state.profileVersion,text:'已把约定收敛为两层：run 固定引用仓库快照；每条分析结论携带文件路径与行号。profile 更新只对下一轮生效，历史回复继续保留原版本。中断会终结当前 run，重试创建新的 run，不回写上一轮结果。'}],facts:[...state.facts,'run 已完成 · 回复已生成。']};
  if(action.type==='tick' && state.status==='running')return {...state,elapsed:state.elapsed+1};
  return state;
}
export function parseRoute(hash='') {
  const parts=hash.replace(/^#\/?/,'').split('/').filter(Boolean);
  const idx=parts.indexOf('chats');
  return {id:idx>=0 ? parts[idx+1]||null:null, info:idx>=0 && parts[idx+2]==='info'};
}
export function routeFor(id=null,info=false,projectId='sprout-refactor') {return '#/projects/'+encodeURIComponent(projectId)+'/chats'+(id?'/'+encodeURIComponent(id):'')+(id&&info?'/info':'');}
export function pageRoute(hash='') {
  const parts=hash.replace(/^#\/?/,'').split('/').filter(Boolean).map(part=>{try{return decodeURIComponent(part)}catch{return part}});
  if(parts[0]==='agents')return {view:parts[1]?'agent-detail':'agents',profileId:parts[1]||null,projectId:null};
  if(parts[0]==='projects'&&!parts[1])return {view:'projects',projectId:null};
  // Project 详情已并入 Settings：/projects/<id> 直接是 Chats，其余子页按段解析。
  if(parts[0]==='projects'&&parts[1])return {view:parts[2]==='agents'?'members':['members','settings'].includes(parts[2])?parts[2]:null,projectId:parts[1]};
  return {view:null,projectId:'sprout-refactor'};
}
export function projectView(hash='') {return pageRoute(hash).view;}
export function projectRouteFor(view,projectId='sprout-refactor') {
  if(view==='projects'||view==='agents')return '#/'+view;
  return '#/projects/'+encodeURIComponent(projectId)+(view==='project-detail'?'':'/'+view);
}
// These fixtures extend the existing presentation data; jobTitle/mark and contextVersion
// are UI annotations, not additional fields in the server's AgentProfile contract.
export const agentProfiles=[...profiles,{id:'shiyan',name:'时砚',mark:'时',jobTitle:'文档协作者',persona:'从使用者的问题出发，写清操作步骤与边界。'}];
export const initialProject={id:'sprout-refactor',name:'Sprout Mio 重构',description:'围绕仓库分析、架构审阅与渐进迁移展开协作。',createdAt:'2026-06-18T02:00:00.000Z',updatedAt:'2026-06-18T02:00:00.000Z'};
export function availableMembers(allProfiles,memberIds){return allProfiles.filter(p=>!memberIds.includes(p.id));}
export function demoError(code,message,operation){return {code,message,requestId:'req_demo_'+operation};}

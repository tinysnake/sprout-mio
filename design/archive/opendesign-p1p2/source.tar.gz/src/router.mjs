// 应用外壳的导航层，与 React 无关，可单独测试。
//
// 为什么需要它：OpenDesign 会把产物注入 srcdoc/sandbox iframe。
//   1) `<a href="#/...">` 的默认导航会被解析成 about:srcdoc 的整页导航并销毁文档；
//   2) 部分宿主里 `location.hash` 赋值被静默忽略或抛 SecurityError，`hashchange` 永不触发。
// 只靠 URL 驱动的界面因此表现为“链接点不动”。这里把两件事拆开：
//   · 同文档 hash 路由：点击一律拦截，直接把目标交给应用注册的 applier 写 React state，
//     URL 只是尽力而为的副作用（sync）。
//   · 跨文档链接：显式解析目标地址；宿主若给不出可导航的地址（about:/data:/blob:），
//     不留下一个点了没反应的死链，而是拦截并通过 onBlocked 让界面说明原因。

const HASH_LINKS = 'a[href]';
const OPAQUE_PROTOCOLS = new Set(['about:', 'data:', 'javascript:', 'blob:']);

export function isPrimaryClick(event) {
  if (!event) return false;
  if (event.button !== undefined && event.button !== 0) return false;
  if (event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return false;
  return true;
}

// 返回同文档 hash 链接；新窗口、下载、外链、空 `#` 都不接管。
export function hashLinkFrom(target) {
  const link = target && typeof target.closest === 'function' ? target.closest(HASH_LINKS) : null;
  if (!link) return null;
  const href = link.getAttribute('href') || '';
  if (!href.startsWith('#')) return null;
  if (href === '#') return null;
  if (link.target) return null;
  if (link.hasAttribute('download')) return null;
  return link;
}

export function createHashRouter({ win = globalThis, logger = console } = {}) {
  let applier = null;
  let mounted = false;

  const apply = hash => {
    if (typeof applier !== 'function') return false;
    try {
      applier(hash);
      return true;
    } catch (error) {
      logger?.error?.(error);
      return false;
    }
  };

  // URL 只做尽力而为的同步：写不进去也不能影响已经完成的页面切换。
  const sync = href => {
    try {
      if (win.location.hash !== href) win.location.hash = href;
      return win.location.hash === href;
    } catch (_) {
      return false;
    }
  };

  const navigate = href => {
    const applied = apply(href);
    const synced = sync(href);
    // 应用器尚未注册（极端时序）时退回事件广播，让监听 hashchange 的旧逻辑兜底。
    if (!applied && typeof applier !== 'function' && synced) {
      try {
        win.dispatchEvent(new win.HashChangeEvent('hashchange'));
      } catch (_) {}
    }
    return { applied, synced };
  };

  // 捕获阶段 + window：宿主或其它监听器可能提前 preventDefault / stopPropagation，
  // 但只要用户点的是同文档 hash 链接，路由就必须由我们接管（不因 defaultPrevented 退出）。
  const handleClick = event => {
    if (!isPrimaryClick(event)) return false;
    const link = hashLinkFrom(event.target);
    if (!link) return false;
    event.preventDefault();
    navigate(link.getAttribute('href'));
    return true;
  };

  // 只用于前进/后退这类外部触发的 URL 变化。
  const handleHashChange = () => apply(win.location.hash);

  const unmount = () => {
    if (!mounted) return;
    mounted = false;
    win.removeEventListener('click', handleClick, true);
    win.removeEventListener('hashchange', handleHashChange);
  };

  const mount = () => {
    if (mounted) return unmount;
    mounted = true;
    win.addEventListener('click', handleClick, true);
    win.addEventListener('hashchange', handleHashChange);
    return unmount;
  };

  return {
    // 注册唯一的状态写入器（React 侧），返回注销函数。
    setApplier(fn) {
      applier = typeof fn === 'function' ? fn : null;
      return () => {
        if (applier === fn) applier = null;
      };
    },
    hasApplier: () => typeof applier === 'function',
    apply,
    sync,
    navigate,
    handleClick,
    handleHashChange,
    mount,
    unmount,
    get mounted() {
      return mounted;
    },
  };
}

// 把相对页地址解析成可导航的绝对地址。宿主用 srcdoc/blob 承载产物时拿不到可导航的基地址，
// 这时 navigable=false —— 调用方必须显式处理，不要假装链接可用。
export function resolvePageHref(href, loc = globalThis.location) {
  const raw = String(href ?? '');
  if (!raw) return { href: raw, navigable: false, file: raw, reason: 'empty' };
  let url = null;
  try {
    url = new URL(raw, loc && loc.href ? loc.href : undefined);
  } catch (_) {
    return { href: raw, navigable: false, file: raw, reason: 'no-base' };
  }
  if (OPAQUE_PROTOCOLS.has(url.protocol)) {
    return { href: raw, navigable: false, url, file: raw, reason: 'opaque' };
  }
  return { href: url.href, navigable: true, url, file: raw };
}

// 跨文档链接（登录、组件样板、演示索引、账号菜单）的点击守卫。
// 可导航时把 href 落成绝对地址并放行浏览器默认行为；不可导航时拦截并回报。
export function installPageLinks({ win = globalThis, onBlocked } = {}) {
  const handle = event => {
    if (!isPrimaryClick(event)) return false;
    const target = event.target;
    const link = target && typeof target.closest === 'function' ? target.closest('a[data-page-link]') : null;
    if (!link) return false;
    const raw = link.getAttribute('href') || '';
    const page = resolvePageHref(raw, win.location);
    if (!page.navigable) {
      event.preventDefault();
      onBlocked?.({ href: raw, file: raw.split('?')[0], reason: page.reason });
      return true;
    }
    if (page.href !== raw) link.setAttribute('href', page.href);
    return false;
  };
  win.addEventListener('click', handle, true);
  return () => win.removeEventListener('click', handle, true);
}

// 登录成功这类“必须换文档”的跳转：先确认地址可导航，再交给 location.assign。
export function assignPage(href, { win = globalThis } = {}) {
  const page = resolvePageHref(href, win.location);
  if (!page.navigable) return { ...page, navigated: false };
  try {
    win.location.assign(page.href);
    return { ...page, navigated: true };
  } catch (error) {
    return { ...page, navigated: false, error };
  }
}

import {readFile,writeFile} from 'node:fs/promises';
function linear(v){return v<=.04045?v/12.92:((v+.055)/1.055)**2.4}
function rgb(hex){return [1,3,5].map(i=>parseInt(hex.slice(i,i+2),16)/255)}
function lch(hex){const [r,g,b]=rgb(hex).map(linear);const l=Math.cbrt(.4122214708*r+.5363325363*g+.0514459929*b),m=Math.cbrt(.2119034982*r+.6806995451*g+.1073969566*b),s=Math.cbrt(.0883024619*r+.2817188376*g+.6299787005*b);const L=.2104542553*l+.793617785*m-.0040720468*s,a=1.9779984951*l-2.428592205*m+.4505937099*s,B=.0259040371*l+.7827717662*m-.808675766*s;return [L,Math.hypot(a,B),(Math.atan2(B,a)*180/Math.PI+360)%360]}
function luminanceLCH(L,C,h){const angle=h*Math.PI/180,a=C*Math.cos(angle),b=C*Math.sin(angle),l=(L+.3963377774*a+.2158037573*b)**3,m=(L-.1055613458*a-.0638541728*b)**3,s=(L-.0894841775*a-1.291485548*b)**3;const r=4.0767416621*l-3.3077115913*m+.2309699292*s,g=-1.2684380046*l+2.6097574011*m-.3413193965*s,B=-.0041960863*l-.7034186147*m+1.707614701*s;return .2126*Math.max(0,r)+.7152*Math.max(0,g)+.0722*Math.max(0,B)}
function lum(hex){return rgb(hex).map(linear).reduce((a,v,i)=>a+v*[.2126,.7152,.0722][i],0)}
function ratio(a,b){return (Math.max(a,b)+.05)/(Math.min(a,b)+.05)}
const css=await readFile('src/app.css','utf8');
const cursorCSS=await readFile('src/cursor-tokens.css','utf8');
const declarations=block=>Object.fromEntries([...block.replace(/\/\*[\s\S]*?\*\//g,'').matchAll(/(--[\w-]+)\s*:\s*([^;]+);/g)].map(([,name,value])=>[name,value.trim()]));
const base=declarations(cursorCSS.replace(/\/\*[\s\S]*?\*\//g,'').match(/:root\s*\{([\s\S]*?)\}/)[1]);
const lightValues={...base,...declarations(css.match(/:root\s*\{([\s\S]*?)\}/)[1])};
const darkValues={...lightValues,...declarations(css.match(/\.dark\s*\{([\s\S]*?)\}/)[1])};
function mix(a,b,p){let h1=a[2],h2=b[2];if(a[1]<.0001)h1=h2;if(b[1]<.0001)h2=h1;const delta=((h2-h1+540)%360)-180;return [a[0]*p+b[0]*(1-p),a[1]*p+b[1]*(1-p),(h1+delta*(1-p)+360)%360]}
function color(value,values){
 value=value.replace(/var\((--[\w-]+)\)/g,(_,name)=>{if(!values[name])throw new Error(`未知颜色 ${name}`);return values[name]});
 if(value.includes('var('))return color(value,values);
 if(value.startsWith('#'))return lch(value);
 if(value.startsWith('oklch('))return value.slice(6,-1).trim().split(/\s+/).slice(0,3).map(Number);
 if(value.startsWith('color-mix(in oklch,')){
  const parts=value.slice('color-mix(in oklch,'.length,-1).split(',').map(s=>s.trim());
  const first=parts[0].match(/^(.*)\s+(\d+(?:\.\d+)?)%$/);if(!first)throw new Error(`无法解析 ${value}`);
  return mix(color(first[1],values),color(parts[1],values),Number(first[2])/100);
 }
 throw new Error(`不支持的颜色 ${value}`);
}
const results=[];
for(const [theme,values]of Object.entries({light:lightValues,dark:darkValues})){
 const c=name=>color(`var(--${name})`,values),L=value=>luminanceLCH(...value);
 const primary=c('primary'),text=c('primary-foreground'),hover=mix(primary,c('fg'),.9),active=mix(primary,c('fg'),.82);
 const pairs=[['主内容正文',c('foreground'),c('background')],['主内容辅助文字',c('muted-foreground'),c('background')],['次级区域正文',c('foreground'),c('secondary')],['次级区域辅助文字',c('muted-foreground'),c('secondary')],['侧栏辅助文字',c('muted-foreground'),c('sidebar')],['正文',c('foreground'),c('card')],['辅助文字',c('muted-foreground'),c('card')],['选中项辅助文字',c('muted-foreground'),c('selected')],['列表项文字（悬停）',c('foreground'),c('hover')],['列表项文字（选中）',c('foreground'),c('selected')],['列表项辅助文字（悬停）',c('muted-foreground'),c('hover')],['错误文字',c('destructive'),c('destructive-soft')],['空闲徽标',c('status-success'),c('card')],['排队徽标',c('status-warning'),c('card')],['运行徽标',c('foreground'),c('muted')],['主按钮',text,primary],['主按钮悬停',text,hover],['主按钮按下',text,active],['个人头像文字',text,primary],['选中图标与底色',primary,c('selected'),3],['选中图标与侧栏',primary,c('sidebar'),3],['聚焦环与画布',c('ring'),c('background'),3],['聚焦环与输入区',c('ring'),c('card'),3]];
 for(const[name,a,b,minimum=4.5]of pairs){const value=ratio(L(a),L(b));if(value<minimum)throw new Error(`${theme} ${name} 对比不足: ${value}`);results.push({theme,name,ratio:Number(value.toFixed(2))})}
 if(ratio(L(text),L(hover))<ratio(L(text),L(primary)))throw new Error(`${theme} 主按钮悬停降低对比`);
}
let inRoot=false;for(const line of css.split('\n')){if(/^:root\s*\{/.test(line))inRoot=true;if(/#[0-9a-fA-F]{3,8}\b/.test(line)&&!inRoot)throw new Error('token 块外出现裸色值');if(inRoot&&line.trim()==='}')inRoot=false;}
const files=['sprout-mio.html','sprout-login.html','sprout-components.html','index.html','sprout-mobile.html'];
for(const file of files){const html=await readFile(file,'utf8');if(/\[REPLACE\]|lorem ipsum|\{\{(?:EMAIL|placeholder)/i.test(html))throw new Error(`${file} 存在未填内容`);if(/<img\b[^>]*src=["']https?:/i.test(html))throw new Error(`${file} 存在远程图片`);if(!html.includes('lang="zh-CN"'))throw new Error(`${file} 语言错误`);if(/<\/?script[\s>]/i.test(html.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi,'')))throw new Error(`${file} script 未闭合`)}
await writeFile('build/contrast-report.json',JSON.stringify(results,null,2)+'\n');
console.log(JSON.stringify({contrastChecks:results.length,minimumContrast:Math.min(...results.map(r=>r.ratio)),htmlFiles:files.length,baseOKLCH:Object.fromEntries(Object.entries({bg:'#f2f1ed',surface:'#e6e5e0',fg:'#26251e',accent:'#f54e00'}).map(([k,v])=>[k,lch(v).map(n=>Number(n.toFixed(5)))]))},null,2));

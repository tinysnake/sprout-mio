import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {execFileSync} from 'node:child_process';
import {build} from 'esbuild';
await mkdir('build',{recursive:true});
execFileSync(process.execPath,['node_modules/@tailwindcss/cli/dist/index.mjs','-i','src/app.css','-o','build/app.css','--minify'],{stdio:'inherit'});
const bundled=await build({entryPoints:['src/app.jsx'],bundle:true,write:false,minify:true,format:'iife',target:['es2020'],jsx:'automatic',define:{'process.env.NODE_ENV':'"production"'},legalComments:'inline'});
const script=bundled.outputFiles[0].text;
// 颜色令牌来自 tokens.css（由 sprout-mio/src/theme.css 生成），非颜色令牌在 cursor-tokens.css。
const [tokenSource,designTokens,css,font]=await Promise.all([readFile('src/cursor-tokens.css','utf8'),readFile('src/tokens.css','utf8'),readFile('build/app.css','utf8'),readFile('node_modules/@fontsource-variable/geist/files/geist-latin-wght-normal.woff2')]);
const fontCSS=`@font-face{font-family:Geist;font-style:normal;font-weight:100 900;font-display:swap;src:url(data:font/woff2;base64,${font.toString('base64')}) format('woff2');unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+20A0-20AB,U+20AD-20C0,U+2113,U+2C60-2C7F,U+A720-A7FF}`;
// Derive catalog swatches from the same CSS that the application uses.
const declarations=block=>Object.fromEntries([...block.replace(/\/\*[\s\S]*?\*\//g,'').matchAll(/(--[\w-]+)\s*:\s*([^;]+);/g)].map(([,name,value])=>[name,value.trim()]));
const sourceCSS=designTokens;
// 基础色板现在来自 tokens.css；cursor-tokens.css 只剩非颜色令牌。
const cursorColors=declarations(designTokens.replace(/\/\*[\s\S]*?\*\//g,'').match(/:root\s*\{([\s\S]*?)\}/)[1]);
const lightColors={...cursorColors,...declarations(sourceCSS.match(/:root\s*\{([\s\S]*?)\}/)[1])};
const darkColors={...lightColors,...declarations(sourceCSS.match(/\.dark\s*\{([\s\S]*?)\}/)[1])};
const resolveColor=(name,values)=>values[name].replace(/var\((--[\w-]+)\)/g,(_,ref)=>resolveColor(ref,values));
const colorRoles={'background':'主内容背景','foreground':'正文与标题','card':'卡片容器','card-foreground':'卡片文字','popover':'浮层背景','popover-foreground':'浮层文字','muted':'弱化背景','muted-foreground':'辅助文字','border':'分隔与容器','input':'输入边框','ring':'键盘聚焦','primary':'主要操作','primary-foreground':'主按钮文字','secondary':'次级区域背景','secondary-foreground':'次要操作文字','accent':'品牌强调','accent-foreground':'强调区域文字','destructive':'失败与破坏操作','destructive-foreground':'破坏操作反色文字','destructive-soft':'错误提示背景','status-success':'成功状态','status-warning':'警告状态','status-running':'运行中','sidebar':'侧栏背景','selected':'选中背景','hover':'悬停背景','status-idle':'空闲状态','status-queued':'排队状态','status-stopped':'已停止','status-failed':'失败状态','status-unknown':'未知状态','status-unimplemented':'未实现','status-interrupted':'宿主重启中断','overlay':'遮罩背景'};
const paletteGroups=[
 ['基础色与表面层级',[['--bg','页面画布'],['--surface-warm','按钮表面'],['--surface','内容表面'],['--fg','主要文字'],['--accent-on','纯白']]],
 ['文字与边框',[['--fg-2','次级文字'],['--muted','辅助文字'],['--meta','元信息'],['--border','标准边框'],['--border-soft','细分隔']]],
 ['强调与交互',[['--accent','品牌橙'],['--accent-hover','强调悬停'],['--accent-active','强调按下'],['--success','成功'],['--warn','警告'],['--danger','错误与悬停']]]
];
const catalogColors={semantic:Object.entries(colorRoles).map(([name,role])=>({name,role,light:resolveColor('--'+name,lightColors),dark:resolveColor('--'+name,darkColors)})),cursor:paletteGroups.map(([title,items])=>({title,items:items.map(([name,role])=>({name,role,value:resolveColor(name,cursorColors)}))}))};
// Additional colors explicitly listed by Cursor DESIGN.md, outside the shared token schema.
catalogColors.cursor.push(...[
 ['补充表面与金色',[['Surface 100','最浅表面','f7f7f4'],['Surface 500','加深表面','e1e0db'],['Gold','高级强调','c08532'],['True Black','代码专用','000000']]],
 ['Agent 操作标记',[['Thinking','思考','dfa88f'],['Grep','搜索','9fc9a2'],['Read','读取','9fbbe0'],['Edit','编辑','c0a8dd']]]
].map(([title,items])=>({title,items:items.map(([name,role,hex])=>({name,role,value:`rgb(${[0,2,4].map(i=>parseInt(hex.slice(i,i+2),16)).join(' ')})`,label:'#'+hex}))})));
catalogColors.cursor.push({title:'补充边框层级',items:[{name:'Border Medium',role:'强调边框',value:'oklab(0.263084 -0.00230259 0.0124794 / 0.2)'},{name:'Border Strong',role:'强边框',value:'rgba(38, 37, 30, 0.55)'},{name:'Border Solid',role:'实色边框',value:cursorColors['--fg']},{name:'Border Light',role:'浅色边框',value:cursorColors['--bg']}]});
const entries=[['sprout-mio.html','workspace','Sprout Mio · Chat 工作台'],['sprout-login.html','login','Sprout Mio · 登录'],['sprout-components.html','components','Sprout Mio · 组件与 token'],['index.html','overview','Sprout Mio · 演示场景索引']];
const target=process.argv[2];
if(target&&!entries.some(([file])=>file===target))throw new Error('未知的构建页面');
for(const [file,page,title]of entries.filter(([file])=>!target||file===target)){
 const html=`<!doctype html>\n<html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,interactive-widget=resizes-content"><meta name="color-scheme" content="light dark"><title>${title}</title><style>\n${designTokens}\n${tokenSource}\n${fontCSS}\n${css}\n</style><script>try{var t=new URLSearchParams(location.search).get('theme')||localStorage.getItem('sprout:theme');document.documentElement.classList.toggle('dark',t==='dark')}catch(e){}</script></head><body><div id="root"></div><noscript>请启用 JavaScript 以运行 Sprout Mio 演示。</noscript><script>window.SPROUT_PAGE=${JSON.stringify(page)};${page==='components'?`window.SPROUT_COLORS=${JSON.stringify(catalogColors)};`:''}</script><script>${script.replaceAll('</script','<\\/script')}</script></body></html>\n`;
 await writeFile(file,html);
}
console.log(target?`已生成 ${target}。`:'已生成工作台、登录、组件样板和演示索引。所有字体、图标、React 与样式已内嵌。');
